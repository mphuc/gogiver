<?php

// HTTP
define('HTTP_SERVER', 'http://localhost/gogiver/admin/');
define('HTTP_CATALOG', 'http://localhost/gogiver/');

// HTTPS
define('HTTPS_SERVER', 'http://localhost/gogiver/admin/');
define('HTTPS_CATALOG', 'http://localhost/gogiver/');

// DIR
define('DIR_APPLICATION', 'C:\xampp\htdocs\gogiver/admin/');
define('DIR_SYSTEM', 'C:\xampp\htdocs\gogiver/system/');
define('DIR_LANGUAGE', 'C:\xampp\htdocs\gogiver/admin/language/');
define('DIR_TEMPLATE', 'C:\xampp\htdocs\gogiver/admin/view/template/');
define('DIR_CONFIG', 'C:\xampp\htdocs\gogiver/system/config/');
define('DIR_IMAGE', 'C:\xampp\htdocs\gogiver/image/');
define('DIR_CACHE', 'C:\xampp\htdocs\gogiver/system/cache/');
define('DIR_DOWNLOAD', 'C:\xampp\htdocs\gogiver/system/download/');
define('DIR_UPLOAD', 'C:\xampp\htdocs\gogiver/system/upload/');
define('DIR_LOGS', 'C:\xampp\htdocs\gogiver/system/logs/');
define('DIR_MODIFICATION', 'C:\xampp\htdocs\gogiver/system/modification/');
define('DIR_CATALOG', 'C:\xampp\htdocs\gogiver/catalog/');

// DB
define('DB_DRIVER', 'mysqli');
define('DB_HOSTNAME', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_DATABASE', 'mmo_gogiver');
define('DB_PORT', '3306');
define('DB_PREFIX', 'sm_');
